import { readFile, writeFile } from 'fs/promises';
import axios from 'axios';

async function gradeResponse() {
  try {
    // Define file paths.  Note the use of template literals correctly.
    const basePath = '/users/shared/repos/grading';
    const userPrompt = await readFile(`${basePath}/prompt-user.txt`, 'utf8');
    const systemPrompt = await readFile(`${basePath}/prompt-system.txt`, 'utf8');
    const responseText = await readFile(`${basePath}/response.txt`, 'utf8');
    const gradingPrompt = await readFile(`${basePath}/prompt-grading.txt`, 'utf8');

    // Combine grading prompt with file contents
    const finalPrompt = `
${gradingPrompt}

Input
System Prompt:
${systemPrompt}

User Prompt:
${userPrompt}

Response:
${responseText}
`;

    // Send request to Ollama
    const response = await axios.post('http://localhost:11434/api/generate', {
      model: 'gemma3:1b',
      prompt: finalPrompt,
      stream: false,
      verbose: true
    });

    // Output the result
    console.log(response.data.response);

    // Save the result to a file.  Again, correct template literal usage.
    await writeFile(`${basePath}/grading-result.txt`, response.data.response);
    console.log('Grading result saved to /users/shared/repos/grading/grading-result.txt');

  } catch (error) {
    console.error('Error during grading:', error); // Log the whole error object for better debugging.
  }
}

gradeResponse();
